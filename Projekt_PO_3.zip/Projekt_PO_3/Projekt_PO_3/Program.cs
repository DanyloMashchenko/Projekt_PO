﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

class Vehicle
{
    public int Id { get; set; }
    public string Brand { get; set; }
}

class Car : Vehicle
{
    public string Model { get; set; }
    public int Year { get; set; }
}

class Truck : Vehicle
{
    public double LoadCapacity { get; set; }
    public string CargoType { get; set; }
}

class ElectricCar : Car
{
    public int Range { get; set; }
    public double BatteryCapacity { get; set; }
}

class GasolineCar : Car
{
    public double EngineCapacity { get; set; }
    public string FuelType { get; set; }
}

class Sedan : Car
{
    public int NumberOfDoors { get; set; }
    public string ComfortFeatures { get; set; }
}

class SUV : Car
{
    public bool OffRoadCapability { get; set; }
    public double CargoCapacity { get; set; }
}

class CarManager
{
    private List<Vehicle> vehicles;
    private string dataFilePath = "CarsData.txt";

    public CarManager()
    {
        vehicles = new List<Vehicle>();
        LoadData();
    }

    public void AddVehicle(Vehicle vehicle)
    {
        vehicle.Id = vehicles.Count + 1;
        vehicles.Add(vehicle);
        SaveData();
    }

    public void UpdateVehicle(int id, Vehicle updatedVehicle)
    {
        Vehicle existingVehicle = vehicles.Find(v => v.Id == id);
        if (existingVehicle != null)
        {
            existingVehicle.Brand = updatedVehicle.Brand;
            if (existingVehicle is Car car)
            {
                car.Model = ((Car)updatedVehicle).Model;
                car.Year = ((Car)updatedVehicle).Year;
            }
            SaveData();
        }
    }

    public void DeleteVehicle(int id)
    {
        Vehicle existingVehicle = vehicles.Find(v => v.Id == id);
        if (existingVehicle != null)
        {
            vehicles.Remove(existingVehicle);
            SaveData();
        }
    }

    public List<Vehicle> GetAllVehicles()
    {
        return vehicles;
    }

    private void LoadData()
    {
        try
        {
            if (File.Exists(dataFilePath))
            {
                foreach (string line in File.ReadLines(dataFilePath))
                {
                    string[] data = line.Split('|');
                    if (data.Length >= 3)
                    {
                        int id = int.Parse(data[0]);
                        string brand = data[1];
                        string model = data[2];

                        if (data.Length == 4 && int.TryParse(data[3], out int year))
                        {
                            vehicles.Add(new Car { Id = id, Brand = brand, Model = model, Year = year });
                        }
                        else
                        {
                            vehicles.Add(new Vehicle { Id = id, Brand = brand });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading data: {ex.Message}");
        }
    }

    private void SaveData()
    {
        try
        {
            List<string> lines = new List<string>();
            foreach (var vehicle in vehicles)
            {
                if (vehicle is Car car)
                {
                    lines.Add($"{car.Id}|{car.Brand}|{car.Model}|{car.Year}");
                }
                else
                {
                    lines.Add($"{vehicle.Id}|{vehicle.Brand}");
                }
            }
            File.WriteAllLines(dataFilePath, lines.ToArray());
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving data: {ex.Message}");
        }
    }
}

class Program
{
    static void Main()
    {
        CarManager carManager = new CarManager();

        Console.WriteLine("Welcome to the Vehicle Management System!");

        while (true)
        {
            Console.WriteLine("\nSelect an option:");
            Console.WriteLine("1. Add Vehicle");
            Console.WriteLine("2. Update Vehicle");
            Console.WriteLine("3. Delete Vehicle");
            Console.WriteLine("4. View All Vehicles");
            Console.WriteLine("5. Exit");

            Console.Write("Enter your choice (1-5): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddVehicle(carManager);
                    break;
                case "2":
                    UpdateVehicle(carManager);
                    break;
                case "3":
                    DeleteVehicle(carManager);
                    break;
                case "4":
                    ViewAllVehicles(carManager);
                    break;
                case "5":
                    Console.WriteLine("Exiting the program. Goodbye!");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    break;
            }
        }
    }

    static void AddVehicle(CarManager carManager)
    {
        Console.WriteLine("\nEnter vehicle details:");

        Console.Write("Brand: ");
        string brand = Console.ReadLine();

        Console.Write("Model: ");
        string model = Console.ReadLine();

        Console.Write("Year: ");
        int year;
        while (!int.TryParse(Console.ReadLine(), out year))
        {
            Console.Write("Invalid input. Please enter a valid year: ");
        }

        Console.Write("Additional details (if any): ");
        string additionalDetails = Console.ReadLine();

        Car newCar = new Car { Brand = brand, Model = model, Year = year };
        carManager.AddVehicle(newCar);

        Console.WriteLine("Vehicle added successfully!");
    }

    static void UpdateVehicle(CarManager carManager)
    {
        Console.Write("\nEnter the ID of the vehicle to update: ");
        int id;
        while (!int.TryParse(Console.ReadLine(), out id))
        {
            Console.Write("Invalid input. Please enter a valid ID: ");
        }

        Vehicle existingVehicle = carManager.GetAllVehicles().Find(v => v.Id == id);
        if (existingVehicle != null)
        {
            Console.WriteLine("\nEnter updated details:");

            Console.Write("Updated Brand: ");
            string updatedBrand = Console.ReadLine();

            Console.Write("Updated Model: ");
            string updatedModel = Console.ReadLine();

            Console.Write("Updated Year: ");
            int updatedYear;
            while (!int.TryParse(Console.ReadLine(), out updatedYear))
            {
                Console.Write("Invalid input. Please enter a valid year: ");
            }

            Car updatedCar = new Car { Brand = updatedBrand, Model = updatedModel, Year = updatedYear };
            carManager.UpdateVehicle(id, updatedCar);

            Console.WriteLine("Vehicle updated successfully!");
        }
        else
        {
            Console.WriteLine($"Vehicle with ID {id} not found.");
        }
    }

    static void DeleteVehicle(CarManager carManager)
    {
        Console.Write("\nEnter the ID of the vehicle to delete: ");
        int id;
        while (!int.TryParse(Console.ReadLine(), out id))
        {
            Console.Write("Invalid input. Please enter a valid ID: ");
        }

        Vehicle existingVehicle = carManager.GetAllVehicles().Find(v => v.Id == id);
        if (existingVehicle != null)
        {
            carManager.DeleteVehicle(id);
            Console.WriteLine("Vehicle deleted successfully!");
        }
        else
        {
            Console.WriteLine($"Vehicle with ID {id} not found.");
        }
    }

    static void ViewAllVehicles(CarManager carManager)
    {
        List<Vehicle> allVehicles = carManager.GetAllVehicles();
        Console.WriteLine("\nAll Vehicles:");

        foreach (var vehicle in allVehicles)
        {
            Console.WriteLine($"ID: {vehicle.Id}, Brand: {vehicle.Brand}");
            if (vehicle is Car car)
            {
                Console.WriteLine($"    Model: {car.Model}, Year: {car.Year}");
            }
        }
    }
}
